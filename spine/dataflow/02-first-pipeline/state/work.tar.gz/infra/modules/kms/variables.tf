variable "region" {
  type = string
}
